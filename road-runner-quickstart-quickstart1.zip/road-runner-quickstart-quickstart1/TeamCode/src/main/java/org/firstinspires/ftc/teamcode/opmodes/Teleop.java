package org.firstinspires.ftc.teamcode.opmodes;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

@Config
@TeleOp(name = "Teleop", group = "Linear Opmode")

public class Teleop extends LinearOpMode {

    DcMotor arm;
    DcMotor slide;
    private static final double DEFAULT_POSITION = 0;;
    SampleMecanumDrive drive;
    static float speed=0.5f;
    private void wait(int ms)
    {
        try{
            Thread.sleep(ms);
        } catch (InterruptedException ignored){
            //nu face nimic
        }
    }
    @Override
    public void runOpMode() throws InterruptedException {
        telemetry.addData("Gamepad1 Left Stick Y", gamepad1.left_stick_y);
        telemetry.addData("Gamepad1 Left Stick X", gamepad1.left_stick_x);
        telemetry.addData("Gamepad1 Right Stick X", gamepad1.right_stick_x);
        telemetry.addData("Gamepad2 A Button", gamepad2.a);
        telemetry.addData("Gamepad2 B Button", gamepad2.b);
        telemetry.update();
        arm = hardwareMap.get(DcMotor.class, "arm");
        slide = hardwareMap.get(DcMotor.class, "slide");

        drive = new SampleMecanumDrive(hardwareMap);
        waitForStart();
        while(opModeIsActive() && !isStopRequested()) {
            drive.setWeightedDrivePower(
                    new Pose2d(
                            gamepad1.left_stick_y * speed,
                            gamepad1.left_stick_x * speed,
                            gamepad1.right_stick_x
                    )
            );
            drive.update();
            if(gamepad2.right_stick_x) {
                arm.setPower(gamepad2.right_stick_x);
            }

          //  idle();
        }
    }
}
